import React from 'react'
import VideoPlayer from '../Components/VideoPlayer/VideoPlayer'


const VideoPage = () => {
  return (
    <>
     <VideoPlayer />
    </>
  )
}

export default VideoPage
