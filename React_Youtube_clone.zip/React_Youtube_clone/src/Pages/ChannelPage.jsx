import React from 'react'
import ChannelDetail from '../Components/ChannelDetail/ChannelDetail'
// import Detail from '../Components/ChannelDetail/ChannelDetail'

const ChannelPage = () => {
  return (
    <div>
     <ChannelDetail />

    </div>
  )
}

export default ChannelPage
