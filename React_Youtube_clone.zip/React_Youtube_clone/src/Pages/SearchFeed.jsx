import React from 'react'
import SearchedVedios from '../Components/searchVedios/SearchedVedios'

const SearchFeed = () => {
  return (
    <>
     <SearchedVedios />
    </>
  )
}

export default SearchFeed
